module.exports = {
  JWT_SECRET: "SecretKey",
};
